from fastapi import FastAPI
from app.routers import chat

app = FastAPI(title="My FastAPI App")

app.include_router(chat.router, prefix="/api/chat", tags=["Chat"])

@app.get("/")
def home():
    return {"message": "FastAPI server ishlayapti!"}
