def get_response(message: str) -> str:
    if "salom" in message.lower():
        return "Salom! Qalaysiz?"
    return "Men sizni tushunmadim."
