from fastapi import APIRouter
from app.schemas.chat_schema import ChatRequest, ChatResponse
from app.services.chat_service import get_response

router = APIRouter()

@router.post("/", response_model=ChatResponse)
def chat_endpoint(data: ChatRequest):
    reply = get_response(data.message)
    return ChatResponse(reply=reply)
