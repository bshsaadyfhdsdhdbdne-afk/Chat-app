# Bu yerda keyinchalik sozlamalar bo'ladi
