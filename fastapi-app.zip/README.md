# FastAPI App

Bu loyiha FastAPI asosida yaratilgan API serverdir.
